"use client";

import { useState, useEffect } from "react";
import { getBreathingInstructions } from "@/app/actions";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { motion, AnimatePresence } from "framer-motion";

const STAGES = [
  { text: "Inhale through your nose", duration: 4000, color: "bg-blue-300/50" },
  { text: "Hold your breath", duration: 7000, color: "bg-purple-300/50" },
  { text: "Exhale through your mouth", duration: 8000, color: "bg-pink-300/50" },
];

interface BreathingExerciseProps {
  onComplete: () => void;
}

export default function BreathingExercise({ onComplete }: BreathingExerciseProps) {
  const [instructions, setInstructions] = useState<string[]>([]);
  const [currentStep, setCurrentStep] = useState(-1); // -1 for initial state
  const [cycle, setCycle] = useState(0);

  useEffect(() => {
    async function fetchInstructions() {
      const fetchedInstructions = await getBreathingInstructions();
      const defaultInstructions = [
        ...STAGES.flatMap(s => s.text),
        ...STAGES.flatMap(s => s.text),
        ...STAGES.flatMap(s => s.text),
      ];
      setInstructions(fetchedInstructions.length > 0 ? fetchedInstructions : defaultInstructions);
      setCurrentStep(0);
    }
    fetchInstructions();
  }, []);

  useEffect(() => {
    if (currentStep >= 0 && instructions.length > 0) {
      if (currentStep >= instructions.length) {
        onComplete();
        return;
      }

      const stageIndex = currentStep % STAGES.length;
      const stage = STAGES[stageIndex];

      const timer = setTimeout(() => {
        setCurrentStep((prev) => prev + 1);
        if ((currentStep + 1) % STAGES.length === 0) {
          setCycle(prev => prev + 1);
        }
      }, stage.duration);

      return () => clearTimeout(timer);
    }
  }, [currentStep, instructions, onComplete]);

  const stageIndex = currentStep % STAGES.length;
  const currentStage = STAGES[stageIndex] || {};
  const instruction = instructions[currentStep] || "";

  if (currentStep === -1) {
    return (
      <Card className="my-4 text-center">
        <CardContent className="p-6">
          <p>Loading exercise...</p>
        </CardContent>
      </Card>
    );
  }

  const isHolding = currentStage.text?.includes("Hold");

  return (
    <Card className="my-4 overflow-hidden border-primary/20 shadow-lg shadow-primary/10">
      <CardHeader>
        <CardTitle className="text-center text-2xl text-primary font-bold">
          4-7-8 Breathing Exercise
        </CardTitle>
      </CardHeader>
      <CardContent className="flex flex-col items-center justify-center p-6 pt-0 min-h-[300px] relative">
        <motion.div
          className="absolute w-64 h-64 rounded-full"
          animate={{
            scale: isHolding ? 1.1 : [1, 1.3, 1],
            backgroundColor: [STAGES[0].color, STAGES[1].color, STAGES[2].color]
          }}
          transition={{
            duration: currentStage.duration / 1000,
            ease: "easeInOut",
            repeat: isHolding ? 0 : Infinity,
            repeatType: "reverse"
          }}
        />
        <AnimatePresence mode="wait">
          <motion.p
            key={currentStep}
            className="z-10 text-2xl font-semibold text-center text-primary-foreground bg-primary/80 px-4 py-2 rounded-lg shadow-md backdrop-blur-sm"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.5 }}
          >
            {instruction}
          </motion.p>
        </AnimatePresence>
        <p className="absolute bottom-6 text-sm text-muted-foreground">
          Breath {cycle + 1} of {Math.max(1, Math.floor(instructions.length / 3))}
        </p>
      </CardContent>
    </Card>
  );
}
