import { useEffect, useRef } from "react";
import { cn } from "@/lib/utils";
import { Message } from "@/app/actions";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { OtrumAILogo } from "@/components/icons";

interface ChatMessagesProps {
  messages: Message[];
  isLoading: boolean;
}

export default function ChatMessages({ messages, isLoading }: ChatMessagesProps) {
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isLoading]);

  return (
    <div className="space-y-6">
      {messages.map((message, index) => (
        <div
          key={message.id}
          className={cn(
            "flex items-start gap-3",
            message.role === "user" ? "justify-end" : "justify-start"
          )}
        >
          {message.role === "ai" && (
            <Avatar className="w-8 h-8 bg-primary/10 text-primary flex items-center justify-center">
              <AvatarFallback>
                <OtrumAILogo className="w-5 h-5" />
              </AvatarFallback>
            </Avatar>
          )}
          <div
            className={cn(
              "max-w-[75%] rounded-2xl px-4 py-3 text-sm md:text-base shadow-sm",
              message.role === "user"
                ? "bg-primary text-primary-foreground rounded-br-none"
                : "bg-muted text-foreground rounded-bl-none",
              "whitespace-pre-wrap leading-relaxed"
            )}
          >
            {message.content}
          </div>
        </div>
      ))}
      {isLoading && (
        <div className="flex items-start gap-3 justify-start">
           <Avatar className="w-8 h-8 bg-primary/10 text-primary flex items-center justify-center">
              <AvatarFallback>
                <OtrumAILogo className="w-5 h-5" />
              </AvatarFallback>
            </Avatar>
          <div className="bg-muted rounded-2xl rounded-bl-none px-4 py-3 flex items-center space-x-2 shadow-sm">
            <span className="h-2 w-2 bg-foreground/50 rounded-full animate-pulse [animation-delay:-0.3s]"></span>
            <span className="h-2 w-2 bg-foreground/50 rounded-full animate-pulse [animation-delay:-0.15s]"></span>
            <span className="h-2 w-2 bg-foreground/50 rounded-full animate-pulse"></span>
          </div>
        </div>
      )}
      <div ref={scrollRef} />
    </div>
  );
}
