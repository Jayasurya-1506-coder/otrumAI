import { Button } from "@/components/ui/button";

const suggestions = [
  "I'm feeling anxious about my upcoming mock test.",
  "How can I deal with pressure from my family?",
  "I can't seem to focus on studying.",
  "I'm worried I'm falling behind.",
];

interface SuggestionPromptsProps {
  onSuggestionClick: (suggestion: string) => void;
}

export default function SuggestionPrompts({ onSuggestionClick }: SuggestionPromptsProps) {
  return (
    <div className="mb-4">
      <p className="text-sm text-muted-foreground mb-2 text-center">Need a conversation starter?</p>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
        {suggestions.map((suggestion) => (
          <Button
            key={suggestion}
            variant="outline"
            className="text-left justify-start h-auto whitespace-normal text-muted-foreground hover:bg-accent/50 hover:text-accent-foreground"
            onClick={() => onSuggestionClick(suggestion)}
          >
            {suggestion}
          </Button>
        ))}
      </div>
    </div>
  );
}
