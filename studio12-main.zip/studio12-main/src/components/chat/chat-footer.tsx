import { Lock } from "lucide-react";

export default function ChatFooter() {
  return (
    <footer className="p-3 border-t bg-background">
      <div className="flex items-center justify-center gap-2 text-xs text-muted-foreground w-full max-w-3xl mx-auto">
        <Lock className="w-3 h-3" />
        <p>This chat is private and anonymous. Your data is not saved.</p>
      </div>
    </footer>
  );
}
