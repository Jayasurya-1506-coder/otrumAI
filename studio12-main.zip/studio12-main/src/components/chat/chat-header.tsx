import { OtrumAILogo } from "@/components/icons";
import { ThemeToggle } from "@/components/theme-toggle";

export default function ChatHeader() {
  return (
    <header className="flex items-center justify-between p-4 border-b w-full max-w-3xl mx-auto">
      <div className="flex items-center gap-3">
        <OtrumAILogo className="w-8 h-8 text-primary" />
        <h1 className="text-2xl font-bold text-primary">OtrumAI</h1>
      </div>
      <ThemeToggle />
    </header>
  );
}
