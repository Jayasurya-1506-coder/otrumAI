"use client";

import { useState, useCallback } from "react";
import { nanoid } from "nanoid";
import { getAIResponse, Message } from "@/app/actions";
import ChatHeader from "@/components/chat/chat-header";
import ChatFooter from "@/components/chat/chat-footer";
import ChatMessages from "@/components/chat/chat-messages";
import ChatInput from "@/components/chat/chat-input";
import SuggestionPrompts from "@/components/chat/suggestion-prompts";
import BreathingExercise from "@/components/breathing-exercise";
import GroundingExercise from "@/components/grounding-exercise";
import { Button } from "./ui/button";
import { Card } from "./ui/card";

const GREETING_MESSAGE: Message = {
  id: "initial-greeting",
  role: "ai",
  content: "Hi there! I'm OtrumAI, your AI companion. How are you feeling today?",
};

export default function ChatContainer() {
  const [messages, setMessages] = useState<Message[]>([GREETING_MESSAGE]);
  const [isLoading, setIsLoading] = useState(false);
  const [activeExercise, setActiveExercise] = useState<"breathing" | "grounding" | null>(null);
  const [exerciseConfirmation, setExerciseConfirmation] = useState<"breathing" | "grounding" | null>(null);

  const handleSendMessage = useCallback(async (content: string) => {
    const userMessage: Message = { id: nanoid(), role: "user", content };
    setMessages((prev) => [...prev, userMessage]);
    setIsLoading(true);
    setExerciseConfirmation(null); // Clear any pending confirmation

    try {
      const { response, isCrisis } = await getAIResponse(messages, content);

      if (isCrisis) {
        const crisisMessage: Message = { id: nanoid(), role: "ai", content: response };
        setMessages((prev) => [...prev, crisisMessage]);
        return;
      }
      
      const toolMatch = response.match(/\[TOOL:(BREATHING|GROUNDING)\]/);
      let aiContent = response;

      if (toolMatch) {
        aiContent = response.replace(toolMatch[0], "").trim();
        const toolType = toolMatch[1].toLowerCase() as "breathing" | "grounding";
        
        if (aiContent) {
            const aiMessage: Message = { id: nanoid(), role: "ai", content: aiContent };
            setMessages((prev) => [...prev, aiMessage]);
        }
        
        setTimeout(() => setExerciseConfirmation(toolType), 500);

      } else {
        const aiMessage: Message = { id: nanoid(), role: "ai", content: aiContent };
        setMessages((prev) => [...prev, aiMessage]);
      }

    } catch (error) {
      console.error("Failed to get AI response:", error);
      const errorMessage: Message = {
        id: nanoid(),
        role: "ai",
        content: "I'm sorry, I seem to be having some trouble right now. Please try again in a moment.",
      };
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  }, [messages]);

  const handleExerciseComplete = () => {
    setActiveExercise(null);
    const followUpMessage: Message = {
      id: nanoid(),
      role: "ai",
      content: "I hope that was helpful. We can continue our chat whenever you're ready.",
    };
    setMessages((prev) => [...prev, followUpMessage]);
  };
  
  const handleConfirmation = (start: boolean) => {
    if (start && exerciseConfirmation) {
      setActiveExercise(exerciseConfirmation);
    } else {
      const cancelMessage: Message = {
        id: nanoid(),
        role: "ai",
        content: "No problem. We can continue our chat.",
      };
      setMessages((prev) => [...prev, cancelMessage]);
    }
    setExerciseConfirmation(null);
  };

  return (
    <div className="flex flex-col h-screen max-h-screen bg-background">
      <ChatHeader />
      <div className="flex-1 overflow-y-auto w-full max-w-3xl mx-auto p-4">
        <ChatMessages messages={messages} isLoading={isLoading} />
        {activeExercise === "breathing" && (
          <BreathingExercise onComplete={handleExerciseComplete} />
        )}
        {activeExercise === "grounding" && (
          <GroundingExercise onComplete={handleExerciseComplete} />
        )}
        {exerciseConfirmation && (
          <Card className="p-4 my-4 flex flex-col items-center gap-4 text-center">
              <p className="font-semibold text-card-foreground">Would you like to start the {exerciseConfirmation} exercise?</p>
              <div className="flex gap-4">
                  <Button onClick={() => handleConfirmation(true)}>Yes, let's start</Button>
                  <Button variant="outline" onClick={() => handleConfirmation(false)}>No, maybe later</Button>
              </div>
          </Card>
        )}
      </div>
      <div className="w-full max-w-3xl mx-auto px-4 pb-4">
        {!activeExercise && messages.length <= 2 && !exerciseConfirmation && (
          <SuggestionPrompts onSuggestionClick={handleSendMessage} />
        )}
        {!activeExercise && !exerciseConfirmation && <ChatInput onSubmit={handleSendMessage} isLoading={isLoading} />}
      </div>
      <ChatFooter />
    </div>
  );
}
