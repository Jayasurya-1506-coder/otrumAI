import { cn } from "@/lib/utils";

export const OtrumAILogo = ({ className, ...props }: React.SVGProps<SVGSVGElement>) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 256 256"
    fill="none"
    className={cn("w-6 h-6", className)}
    {...props}
  >
    <path
      d="M69.172 40.454C47.896 58.048 32.22 83.243 32.22 112.355C32.22 173.23 82.77 223.78 143.645 223.78C161.46 223.78 178.23 219.43 192.83 211.54L133.36 122.9L69.172 40.454Z"
      fill="url(#paint0_linear_1_2)"
    />
    <path
      d="M211.85 68.86C227.52 90.67 236.42 117.8 236.42 147.16C236.42 195.84 204.3 237.21 161.21 250.21L128.52 178.55L211.85 68.86Z"
      fill="url(#paint1_linear_1_2)"
    />
    <path
      d="M40.35 69.17C58.11 47.9 83.31 32.22 112.42 32.22C173.29 32.22 223.85 82.77 223.85 143.65C223.85 161.46 219.5 178.23 211.61 192.83L152.14 104.19L40.35 69.17Z"
      fill="url(#paint2_linear_1_2)"
    />
    <defs>
      <linearGradient
        id="paint0_linear_1_2"
        x1="112.5"
        y1="32"
        x2="112.5"
        y2="224"
        gradientUnits="userSpaceOnUse"
      >
        <stop stopColor="#F5AE6D" />
        <stop offset="1" stopColor="#F2994A" />
      </linearGradient>
      <linearGradient
        id="paint1_linear_1_2"
        x1="243"
        y1="156.5"
        x2="124"
        y2="178.5"
        gradientUnits="userSpaceOnUse"
      >
        <stop stopColor="#6FCF97" />
        <stop offset="1" stopColor="#27AE60" />
      </linearGradient>
      <linearGradient
        id="paint2_linear_1_2"
        x1="32"
        y1="112.5"
        x2="224"
        y2="112.5"
        gradientUnits="userSpaceOnUse"
      >
        <stop stopColor="#56CCF2" />
        <stop offset="1" stopColor="#2D9CDB" />
      </linearGradient>
    </defs>
  </svg>
);
