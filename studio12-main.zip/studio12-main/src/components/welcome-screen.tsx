import { Button } from "@/components/ui/button";
import { OtrumAILogo } from "@/components/icons";

type WelcomeScreenProps = {
  onStartChat: () => void;
};

export default function WelcomeScreen({ onStartChat }: WelcomeScreenProps) {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-background p-4 text-center relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-transparent to-accent/10 -z-10"/>
      <div className="mb-6">
        <OtrumAILogo className="w-28 h-28 mx-auto text-primary" />
      </div>
      <h1 className="text-5xl md:text-6xl font-bold text-primary mb-4 animate-fade-in-down">
        OtrumAI
      </h1>
      <p className="max-w-xl text-lg text-foreground/80 mb-8 animate-fade-in-up">
        Your AI companion. A safe and anonymous space to talk and get support.
      </p>
      <Button onClick={onStartChat} size="lg" className="shadow-lg shadow-primary/20">
        Start Chatting
      </Button>
    </div>
  );
}
