"use client";

import { useState, useEffect } from "react";
import { getGroundingInstruction } from "@/app/actions";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Check, Eye, Ear, Hand, Utensils, Wind } from "lucide-react";

const stageIcons = [
  <Eye className="w-12 h-12" />,
  <Hand className="w-12 h-12" />,
  <Ear className="w-12 h-12" />,
  <Wind className="w-12 h-12" />,
  <Utensils className="w-12 h-12" />,
];

interface GroundingExerciseProps {
  onComplete: () => void;
}

export default function GroundingExercise({ onComplete }: GroundingExerciseProps) {
  const [stage, setStage] = useState(1);
  const [instruction, setInstruction] = useState("Loading exercise...");
  const [isComplete, setIsComplete] = useState(false);

  useEffect(() => {
    async function fetchInstruction() {
      const result = await getGroundingInstruction(stage);
      if (result) {
        setInstruction(result.instruction);
        setIsComplete(result.isExerciseComplete);
      } else {
        setInstruction("There was an issue loading the next step. You can end the exercise now.");
      }
    }
    fetchInstruction();
  }, [stage]);

  const handleNext = () => {
    if (isComplete) {
      onComplete();
    } else {
      setStage((prev) => prev + 1);
    }
  };

  const progressValue = (stage / 5) * 100;

  return (
    <Card className="my-4 border-primary/20 shadow-lg shadow-primary/10">
      <CardHeader>
        <CardTitle className="text-center text-2xl text-primary font-bold">
          5-4-3-2-1 Grounding Exercise
        </CardTitle>
        <CardDescription className="text-center">
          Let's connect with the present moment.
        </CardDescription>
      </CardHeader>
      <CardContent className="flex flex-col items-center justify-center p-6 pt-2 text-center min-h-[200px] gap-6">
        <div className="text-primary/70">
            {stageIcons[stage - 1]}
        </div>
        <p className="text-lg font-semibold">{instruction}</p>
      </CardContent>
      <CardFooter className="flex flex-col gap-4">
        <Progress value={progressValue} className="w-full h-2" />
        <Button onClick={handleNext} className="w-full shadow-md">
          {isComplete ? "Finish Exercise" : "Next Step"}
          {!isComplete && <Check className="w-4 h-4 ml-2" />}
        </Button>
      </CardFooter>
    </Card>
  );
}
