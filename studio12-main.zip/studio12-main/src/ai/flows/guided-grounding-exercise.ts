'use server';
/**
 * @fileOverview A guided grounding exercise AI agent.
 *
 * - guidedGroundingExercise - A function that handles the grounding exercise process.
 * - GuidedGroundingExerciseInput - The input type for the guidedGroundingExercise function.
 * - GuidedGroundingExerciseOutput - The return type for the guidedGroundingExercise function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const GuidedGroundingExerciseInputSchema = z.object({
  exerciseStage: z
    .number()
    .describe("The current stage of the grounding exercise (1-5).  The user doesn't see this.")
    .default(1),
});
export type GuidedGroundingExerciseInput = z.infer<
  typeof GuidedGroundingExerciseInputSchema
>;

const GuidedGroundingExerciseOutputSchema = z.object({
  stage: z.number().describe('The current stage of the exercise.'),
  instruction: z.string().describe('The instruction for the current stage.'),
  isExerciseComplete: z.boolean().describe('Whether the exercise is complete.'),
});
export type GuidedGroundingExerciseOutput = z.infer<
  typeof GuidedGroundingExerciseOutputSchema
>;

export async function guidedGroundingExercise(
  input: GuidedGroundingExerciseInput
): Promise<GuidedGroundingExerciseOutput> {
  return guidedGroundingExerciseFlow(input);
}

const prompt = ai.definePrompt({
  name: 'guidedGroundingExercisePrompt',
  input: {schema: GuidedGroundingExerciseInputSchema},
  output: {schema: GuidedGroundingExerciseOutputSchema},
  prompt: `You are OtrumAI, a helpful AI companion guiding a student through a 5-4-3-2-1 grounding exercise.

  The exercise involves focusing on the five senses to ground oneself in the present moment.

  You must always use supportive and encouraging language. Keep the response short and to the point.

  The current stage of the exercise is: {{exerciseStage}}

  Here are the instructions for each stage:
  - Stage 1: Acknowledge FIVE things you can SEE around you.
  - Stage 2: Acknowledge FOUR things you can TOUCH around you.
  - Stage 3: Acknowledge THREE things you can HEAR around you.
  - Stage 4: Acknowledge TWO things you can SMELL around you.
  - Stage 5: Acknowledge ONE thing you can TASTE around you.

  Based on the current stage, provide the appropriate instruction. Set isExerciseComplete to true only if the stage is 5, otherwise it is false.
  Always set the stage field to the current stage.
  Always respond in English.
`,
});

const guidedGroundingExerciseFlow = ai.defineFlow(
  {
    name: 'guidedGroundingExerciseFlow',
    inputSchema: GuidedGroundingExerciseInputSchema,
    outputSchema: GuidedGroundingExerciseOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
