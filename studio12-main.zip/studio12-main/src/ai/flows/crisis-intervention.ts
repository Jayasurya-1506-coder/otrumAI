'use server';

/**
 * @fileOverview Crisis intervention flow to detect severe distress and provide immediate support.
 *
 * - crisisIntervention - A function that detects crisis and provides support.
 * - CrisisInterventionInput - The input type for the crisisIntervention function.
 * - CrisisInterventionOutput - The return type for the crisisIntervention function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const CrisisInterventionInputSchema = z.object({
  message: z.string().describe('The user message to be checked for distress signals.'),
});
export type CrisisInterventionInput = z.infer<typeof CrisisInterventionInputSchema>;

const CrisisInterventionOutputSchema = z.object({
  isCrisis: z.boolean().describe('Whether the message indicates a crisis situation.'),
  response: z.string().describe('A supportive message and helpline numbers if a crisis is detected.'),
});
export type CrisisInterventionOutput = z.infer<typeof CrisisInterventionOutputSchema>;

export async function crisisIntervention(input: CrisisInterventionInput): Promise<CrisisInterventionOutput> {
  return crisisInterventionFlow(input);
}

const crisisInterventionPrompt = ai.definePrompt({
  name: 'crisisInterventionPrompt',
  input: {schema: CrisisInterventionInputSchema},
  output: {schema: CrisisInterventionOutputSchema},
  prompt: `You are OtrumAI, a mental wellness companion. Your primary task is to identify if a user's message indicates a crisis situation (e.g., thoughts of suicide, self-harm, or extreme hopelessness).

  Analyze the following message:
  {{message}}

  Respond ONLY using the following JSON structure. Do NOT add any conversational text:
  {
    "isCrisis": true or false,
    "response": "A supportive message and helpline numbers if isCrisis is true.  Otherwise, an empty string."
  }

  If the message contains keywords or phrases suggesting a crisis, set "isCrisis" to true and provide the following response:
  "It sounds like you're going through a lot right now, and I want you to know that you're not alone. Please reach out for immediate support. Here are some resources: In a life-threatening emergency, call 911 or your local emergency number. You can also connect with people who can support you by calling or texting 988 anytime in the US and Canada. In the UK, you can call 111."

  If the message does not indicate a crisis, set "isCrisis" to false and leave the response as an empty string.
  `,config: {
    safetySettings: [
      {
        category: 'HARM_CATEGORY_HATE_SPEECH',
        threshold: 'BLOCK_ONLY_HIGH',
      },
      {
        category: 'HARM_CATEGORY_DANGEROUS_CONTENT',
        threshold: 'BLOCK_NONE',
      },
      {
        category: 'HARM_CATEGORY_HARASSMENT',
        threshold: 'BLOCK_MEDIUM_AND_ABOVE',
      },
      {
        category: 'HARM_CATEGORY_SEXUALLY_EXPLICIT',
        threshold: 'BLOCK_LOW_AND_ABOVE',
      },
    ],
  },
});

const crisisInterventionFlow = ai.defineFlow(
  {
    name: 'crisisInterventionFlow',
    inputSchema: CrisisInterventionInputSchema,
    outputSchema: CrisisInterventionOutputSchema,
  },
  async input => {
    const {output} = await crisisInterventionPrompt(input);
    return output!;
  }
);
