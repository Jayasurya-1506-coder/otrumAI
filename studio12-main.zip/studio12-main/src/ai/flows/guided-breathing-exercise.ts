// src/ai/flows/guided-breathing-exercise.ts
'use server';

/**
 * @fileOverview A flow to guide the user through the 4-7-8 breathing exercise.
 *
 * - guidedBreathingExercise - A function that initiates the breathing exercise flow.
 * - GuidedBreathingExerciseInput - The input type for the guidedBreathingExercise function.
 * - GuidedBreathingExerciseOutput - The return type for the guidedBreathingExercise function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const GuidedBreathingExerciseInputSchema = z.object({
  numBreaths: z
    .number()
    .min(1)
    .max(5)
    .default(3)
    .describe('The number of breaths to guide the user through.'),
});
export type GuidedBreathingExerciseInput = z.infer<typeof GuidedBreathingExerciseInputSchema>;

const GuidedBreathingExerciseOutputSchema = z.object({
  instructions: z.array(z.string()).describe('The list of breathing instructions.'),
});
export type GuidedBreathingExerciseOutput = z.infer<typeof GuidedBreathingExerciseOutputSchema>;

export async function guidedBreathingExercise(input: GuidedBreathingExerciseInput): Promise<GuidedBreathingExerciseOutput> {
  return guidedBreathingExerciseFlow(input);
}

const prompt = ai.definePrompt({
  name: 'guidedBreathingExercisePrompt',
  input: {schema: GuidedBreathingExerciseInputSchema},
  output: {schema: GuidedBreathingExerciseOutputSchema},
  prompt: `You are OtrumAI, a helpful AI assistant that guides users through a 4-7-8 breathing exercise.

You will guide the user through the exercise for {{numBreaths}} breaths. For each breath, provide clear and concise instructions for each step (inhale, hold, exhale).  Each instruction should be a single sentence and easy to understand.

The 4-7-8 breathing technique involves the following steps:
1. Inhale quietly through your nose for a count of 4.
2. Hold your breath for a count of 7.
3. Exhale completely through your mouth for a count of 8, making a whooshing sound.

Each instruction should be added to the instructions array.

Example output:
{
  "instructions": [
    "Inhale quietly through your nose for a count of 4.",
    "Hold your breath for a count of 7.",
    "Exhale completely through your mouth for a count of 8, making a whooshing sound.",
    "Inhale quietly through your nose for a count of 4.",
    "Hold your breath for a count of 7.",
    "Exhale completely through your mouth for a count of 8, making a whooshing sound.",
    "Inhale quietly through your nose for a count of 4.",
    "Hold your breath for a count of 7.",
    "Exhale completely through your mouth for a count of 8, making a whooshing sound."
  ]
}

Now generate the instructions for {{numBreaths}} breaths.
`, 
});

const guidedBreathingExerciseFlow = ai.defineFlow(
  {
    name: 'guidedBreathingExerciseFlow',
    inputSchema: GuidedBreathingExerciseInputSchema,
    outputSchema: GuidedBreathingExerciseOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
