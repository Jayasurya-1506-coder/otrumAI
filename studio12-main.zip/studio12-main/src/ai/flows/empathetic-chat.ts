'use server';

/**
 * @fileOverview This file defines the empathetic chat flow for the OtrumAI app.
 *
 * - empatheticChat - The main function to initiate the chat with the empathetic AI.
 * - EmpatheticChatInput - The input type for the empatheticChat function.
 * - EmpatheticChatOutput - The output type for the empatheticChat function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const EmpatheticChatInputSchema = z.object({
  message: z.string().describe('The user message to the AI.'),
});
export type EmpatheticChatInput = z.infer<typeof EmpatheticChatInputSchema>;

const EmpatheticChatOutputSchema = z.object({
  response: z.string().describe('The AI response to the user message.'),
});
export type EmpatheticChatOutput = z.infer<typeof EmpatheticChatOutputSchema>;

export async function empatheticChat(input: EmpatheticChatInput): Promise<EmpatheticChatOutput> {
  return empatheticChatFlow(input);
}

const empatheticChatPrompt = ai.definePrompt({
  name: 'empatheticChatPrompt',
  input: {schema: EmpatheticChatInputSchema},
  output: {schema: EmpatheticChatOutputSchema},
  prompt: `You are OtrumAI, an empathetic and non-judgmental AI friend. Your goal is to provide emotional support and practical wellness tips.

  Here are some key principles to guide your responses:

  *   Always validate the user's feelings first. Show that you understand and acknowledge their emotions.
  *   Maintain a supportive, peer-like tone. Responses must be in English only.
  *   Never ask for personally identifiable information.
  *   If you determine that a guided exercise is appropriate, you MUST include one of the following strings in your response, on a new line by itself: \`[TOOL:BREATHING]\` or \`[TOOL:GROUNDING]\`. For example: "It sounds like a breathing exercise might help. Let's try one together.\\n[TOOL:BREATHING]"

  User Message: {{{message}}}
  `,
  tools: [],
});

const empatheticChatFlow = ai.defineFlow(
  {
    name: 'empatheticChatFlow',
    inputSchema: EmpatheticChatInputSchema,
    outputSchema: EmpatheticChatOutputSchema,
  },
  async input => {
    const {output} = await empatheticChatPrompt(input);
    return output!;
  }
);
