"use client";

import { useState } from "react";
import WelcomeScreen from "@/components/welcome-screen";
import ChatContainer from "@/components/chat-container";
import { AnimatePresence, motion } from "framer-motion";

export default function Home() {
  const [chatStarted, setChatStarted] = useState(false);

  return (
    <AnimatePresence mode="wait">
      {!chatStarted ? (
        <motion.div
          key="welcome"
          exit={{ opacity: 0, scale: 0.95 }}
          transition={{ duration: 0.3 }}
        >
          <WelcomeScreen onStartChat={() => setChatStarted(true)} />
        </motion.div>
      ) : (
        <motion.div
          key="chat"
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
          className="h-full"
        >
          <ChatContainer />
        </motion.div>
      )}
    </AnimatePresence>
  );
}
