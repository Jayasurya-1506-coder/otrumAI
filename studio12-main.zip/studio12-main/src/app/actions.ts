"use server";

import { crisisIntervention } from "@/ai/flows/crisis-intervention";
import { empatheticChat } from "@/ai/flows/empathetic-chat";
import { guidedBreathingExercise } from "@/ai/flows/guided-breathing-exercise";
import { guidedGroundingExercise } from "@/ai/flows/guided-grounding-exercise";

export type Message = {
  id: string;
  role: "user" | "ai" | "system" | "tool";
  content: string;
  toolOutput?: any;
};

export async function getAIResponse(history: Message[], newMessage: string) {
  const crisisCheck = await crisisIntervention({ message: newMessage });
  if (crisisCheck.isCrisis) {
    return { response: crisisCheck.response, isCrisis: true };
  }

  // A more advanced implementation would pass the full history.
  // For this app, we follow the simple schema of the AI flow.
  const chatResponse = await empatheticChat({ message: newMessage });
  return { response: chatResponse.response, isCrisis: false };
}

export async function getBreathingInstructions() {
  try {
    const result = await guidedBreathingExercise({ numBreaths: 3 });
    return result.instructions;
  } catch (error) {
    console.error("Error getting breathing instructions:", error);
    return [];
  }
}

export async function getGroundingInstruction(stage: number) {
  try {
    const result = await guidedGroundingExercise({ exerciseStage: stage });
    return result;
  } catch (error) {
    console.error("Error getting grounding instruction:", error);
    return null;
  }
}
