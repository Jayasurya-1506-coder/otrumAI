# **App Name**: Saathi: Exam Wellness Companion

## Core Features:

- Welcome Screen: Display a welcome screen with app name, message, and 'Start Chatting' button.
- Chat Interface: Implement a clean chat interface with user/AI messages and suggestion prompts.
- Empathetic AI Chat: Use the Genkit 'empatheticChat' flow with the 'Saathi' persona for supportive conversations and validation. The Saathi persona will suggest simple and practical wellness tools when appropriate. It will act as a tool to determine when those recommendations are useful.
- Crisis Intervention: Implement a safety layer to detect distress and provide helpline numbers using a Genkit tool.
- Guided Breathing Exercise: Guide users through the 4-7-8 breathing technique via the AI chatbot. Breathing is initiated in the empathetic AI chat, but hands off control to this tool for the duration of the exercise, then resumes the normal empathetic AI flow afterward.
- Guided Grounding Exercise: Guide users through the 5-4-3-2-1 grounding technique via the AI chatbot. Grounding is initiated in the empathetic AI chat, but hands off control to this tool for the duration of the exercise, then resumes the normal empathetic AI flow afterward.
- Dark/Light Mode Toggle: Implement a toggle for switching between dark and light modes.

## Style Guidelines:

- Primary color: Muted teal (#73A580) for a calming and professional feel.
- Background color: Light beige (#F5F5DC) to promote a serene and safe environment.
- Accent color: Soft coral (#F08080) for highlights and important UI elements.
- Headline Font: 'Belleza' (sans-serif) for a pleasant, high-end feel.
- Body Font: 'PT Sans' (sans-serif) for body copy to ensure readability and contemporary style.
- Use a clean, modern layout with rounded corners, soft shadows, and plenty of whitespace.
- Distinguish user/AI chat messages clearly in the layout.